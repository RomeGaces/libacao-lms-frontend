<template>
  <div class="calendar-header-wrapper">
    <h1 class="title">Class Scheduler</h1>
  </div>
</template>

<script setup lang="ts">
// No script needed for now — pure UI
</script>

<style scoped>
.calendar-header-wrapper {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 18px;
  padding: 4px 0;
}

.title {
  font-size: 1.75rem;
  font-weight: 600;
  letter-spacing: 0.025em;
  color: #e4e7ec;
}
</style>
