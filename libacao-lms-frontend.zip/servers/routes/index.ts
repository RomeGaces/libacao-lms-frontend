import { defineEventHandler } from 'h3'

export default defineEventHandler(() => {
  return { nitro: 'Hello Antdv Pro' }
})
