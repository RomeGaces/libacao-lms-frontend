// This constant defines the name of the configuration file that will be used in the production environment
export const GLOB_CONFIG_FILE_NAME = '_app.config.js'

// This constant sets the output directory for the Vite package
export const OUTPUT_DIR = 'dist'
