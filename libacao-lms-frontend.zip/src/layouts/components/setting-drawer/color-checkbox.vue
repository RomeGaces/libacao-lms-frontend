<script setup lang="ts">
defineProps<{ color: string }>()
</script>

<template>
  <div>
    <!--  -->
  </div>
</template>
