<script setup lang="ts">
</script>

<template>
  <div>
    Ordinary users have the right to view Super administrators also have the right
  </div>
</template>
