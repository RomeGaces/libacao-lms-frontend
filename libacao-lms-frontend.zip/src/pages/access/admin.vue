<script setup lang="ts">
</script>

<template>
  <div>
    管理员拥有访问权限
  </div>
</template>
