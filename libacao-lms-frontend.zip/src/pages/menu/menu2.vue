<script setup lang="ts">

</script>

<template>
  <div>
    Menu2
    <a-input />
  </div>
</template>
