<script setup lang="ts">

</script>

<template>
  <div>
    Menu1
    <a-input />
  </div>
</template>
