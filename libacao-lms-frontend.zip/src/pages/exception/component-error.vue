<script setup lang="ts">

</script>

<template>
  <a-result status="404" title="页面配置错误" sub-title="动态配置页面不存在，请检查配置项" />
</template>
