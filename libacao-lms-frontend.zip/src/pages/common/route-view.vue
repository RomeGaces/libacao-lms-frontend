<script setup lang="ts">
defineOptions({
  name: 'RouteView',
})
</script>

<template>
  <RouterView />
</template>
