<script setup lang="ts">
import { useLayoutMenuProvide } from '~/components/page-container/context'

const appStore = useAppStore()
const { theme } = storeToRefs(appStore)
const { antd } = useI18nLocale()
const layoutMenu = useLayoutMenu()
useLayoutMenuProvide(layoutMenu, appStore)
</script>

<template>
  <a-config-provider :theme="theme" :locale="antd">
    <a-app class="h-full antialiased">
      <TokenProvider>
        <RouterView />
      </TokenProvider>
    </a-app>
  </a-config-provider>
</template>
