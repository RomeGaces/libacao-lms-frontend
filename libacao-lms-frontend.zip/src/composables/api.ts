import { useDelete, useGet, usePost, usePut } from '~/utils/request'

export {
  useDelete,
  useGet,
  usePost,
  usePut,
}
